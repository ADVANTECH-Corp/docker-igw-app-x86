#!/bin/bash
# Program:
#       install greengrass dependency and EISSDK dependency 
#	pull EISdocker 
#	create ggc_user and ggc_group for greengrass use
# History:
# 2018/07/16	VBird	First release

apt-get update
#install greengrass dependency
apt-get install -y sqlite3

#create ggc_user and ggc_group for greengrass use
adduser --system ggc_user
addgroup --system  ggc_group

#install EISSDK dependency
apt-get install -y libmosquitto-dev

#unzipped EIS SDK lib
tar xvf EISpackage.tar.gz
sudo cp -a EISSDK/libEIServiceSDK.so* /usr/lib/.

#unzipped Greengrass 
tar xvf greengrass-linux-x86-64-1.3.0.tar.gz
#unzipped Protocol connector sample 
tar xvf ProtocolConnectorSample.tar.gz



